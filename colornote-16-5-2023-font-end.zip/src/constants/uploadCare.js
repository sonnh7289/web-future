export const uploadCareUrl = (id) => "https://ucarecdn.com/" + id;
