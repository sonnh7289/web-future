export { default as LandingPage } from "./LandingPage";
